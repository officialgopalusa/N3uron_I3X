@echo off
cd /d "C:\I3X DAA\server"
echo Starting I3X API Server in the background...
:: Use PowerShell to start the process in a hidden window so it persists
powershell -Command "Start-Process '.\venv\Scripts\python.exe' -ArgumentList 'app.py' -WorkingDirectory 'C:\I3X DAA\server' -WindowStyle Hidden"
echo Server started. You can close this window.
timeout /t 3
