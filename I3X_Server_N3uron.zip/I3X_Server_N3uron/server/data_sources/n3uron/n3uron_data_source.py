import json
import os
import requests
import threading
import time
from typing import List, Optional, Dict, Any, Callable
from datetime import datetime, timezone

# Handle relative import depending on how it's called
try:
    from ..data_interface import I3XDataSource
except (ImportError, ValueError):
    # Fallback for standalone tests if needed
    class I3XDataSource:
        pass

class N3uronDataSource(I3XDataSource):
    """N3uron REST implementation of I3XDataSource"""

    def __init__(self, config: Dict[str, Any] = None):
        """
        Initialize the N3uron data source
        
        Args:
            config: Dict containing:
                - url: N3uron REST endpoint (default: http://localhost:3003/tag)
                - path: Root path to read from (default: /MainPlant/*)
                - poll_interval: Seconds between polls (default: 5.0)
        """
        self.config = config or {}
        self.base_url = self.config.get("url", "http://localhost:3003/tag")
        self.path = self.config.get("path", "/MainPlant/*")
        
        # Authentication
        self.username = self.config.get("username", "admin")
        self.password = self.config.get("password", "admin")
        self.auth = (self.username, self.password) if self.username else None
        
        # Internal cache for objects and values
        self._instances = []
        self._raw_data = {}
        
        self.update_callback = None
        self.running = False
        self.thread = None
        self.poll_interval = float(self.config.get("poll_interval", 5.0))

    def start(self, update_callback: Optional[Callable[[Dict[str, Any]], None]] = None) -> None:
        """Start the background polling thread"""
        self.update_callback = update_callback
        self.running = True
        
        # Start thread immediately - initial refresh will happen inside the loop
        self.thread = threading.Thread(target=self._poll_loop, daemon=True)
        self.thread.start()
        print(f"N3uron DataSource started. Polling {self.base_url} every {self.poll_interval}s")

    def stop(self) -> None:
        """Stop the background polling thread"""
        self.running = False
        if self.thread:
            self.thread.join(timeout=2)
            print("N3uron DataSource stopped.")

    def _poll_loop(self):
        """Background thread for periodic data updates"""
        while self.running:
            try:
                self._refresh_data()
                time.sleep(self.poll_interval)
            except Exception as e:
                print(f"N3uron Polling Error: {e}")
                time.sleep(5)

    def _refresh_data(self):
        """Fetch data from N3uron and transform to I3X format"""
        try:
            params = {
                "cmd": "read",
                "path": self.path,
                "options.recurrent": "true"
            }
            
            # Using timeout and auth to fetch real-time data
            response = requests.get(self.base_url, params=params, auth=self.auth, timeout=5)
            
            if response.status_code == 200:
                raw_json = response.json()
                self._raw_data = raw_json
                self._parse_n3uron_tree(raw_json)
            else:
                print(f"N3uron API Error: HTTP {response.status_code}")
                
        except requests.exceptions.ConnectionError:
            # Silently handle connection errors (site might be down)
            pass
        except Exception as e:
            print(f"N3uron Refresh Error: {e}")

    def _parse_n3uron_tree(self, raw_data):
        """Recursively parses the N3uron groups/tags tree into I3X instances"""
        new_instances = []

        def recurse(node, parent_id="/"):
            # 1. Process Groups (Folders in I3X)
            groups = node.get("groups", {})
            for group_name, group_content in groups.items():
                group_id = f"{parent_id}/{group_name}".strip("/").replace(" ", "-").lower()
                
                # Identify children (both sub-groups and sub-tags)
                child_groups = [f"{group_id}/{name}".replace(" ", "-").lower() for name in group_content.get("groups", {}).keys()]
                child_tags = [f"{group_id}/{name}".replace(" ", "-").lower() for name in group_content.get("tags", {}).keys()]
                all_children = child_groups + child_tags
                
                instance = {
                    "elementId": group_id,
                    "displayName": group_name,
                    "namespaceUri": "http://n3uron.com/tags",
                    "typeId": "folder-type",
                    "parentId": parent_id,
                    "isComposition": True,
                    "relationships": {
                        "HasParent": parent_id,
                        "HasComponent": all_children
                    }
                }
                new_instances.append(instance)
                recurse(group_content, group_id)

            # 2. Process Tags (Measurement values in I3X)
            tags = node.get("tags", {})
            for tag_name, tag_content in tags.items():
                tag_id = f"{parent_id}/{tag_name}".strip("/").replace(" ", "-").lower()
                
                # Get the value and meta
                data = tag_content.get("data", {})
                v = data.get("value")
                q = "GOOD" if data.get("quality") == 192 else "UNCERTAIN"
                
                # Convert N3uron timestamp (ms) to ISO 8601
                ts_ms = data.get("ts", time.time() * 1000)
                dt = datetime.fromtimestamp(ts_ms / 1000.0, tz=timezone.utc)
                ts_iso = dt.strftime("%Y-%m-%dT%H:%M:%SZ")

                vqt = {
                    "value": v,
                    "quality": q,
                    "timestamp": ts_iso
                }

                instance = {
                    "elementId": tag_id,
                    "displayName": tag_name,
                    "namespaceUri": "http://n3uron.com/tags",
                    "typeId": "measurement-type",
                    "parentId": parent_id,
                    "isComposition": False,
                    "relationships": {
                        "ComponentOf": parent_id
                    },
                    "records": [vqt]
                }
                new_instances.append(instance)
                
                # If we have a subscription callback, notify it of the new value
                if self.update_callback:
                    self.update_callback(instance, vqt)

        # Clear and build new cache
        recurse(raw_data)
        self._instances = new_instances

    # I3XDataSource implementation methods
    def get_namespaces(self) -> List[Dict[str, Any]]:
        return [
            {"uri": "http://n3uron.com/tags", "displayName": "N3uron Nodes"},
            {"uri": "https://isa.org/isa95", "displayName": "ISA-95"}
        ]

    def get_instances(self, type_id: Optional[str] = None) -> List[Dict[str, Any]]:
        if type_id:
            return [i for i in self._instances if i["typeId"] == type_id]
        return [ {k:v for k,v in i.items() if k != "records"} for i in self._instances]

    def get_instance_by_id(self, element_id: str, values: bool = False) -> Optional[Dict[str, Any]]:
        for i in self._instances:
            if i["elementId"] == element_id:
                if values:
                    return i
                return {k:v for k,v in i.items() if k != "records"}
        return None

    def get_instance_values_by_id(self, element_id: str, startTime=None, endTime=None, maxDepth=1, returnHistory=False):
        instance = self.get_instance_by_id(element_id, values=True)
        if not instance:
            return None
            
        # Get own VQT
        records = instance.get("records", [])
        result = { "data": records }
        
        # Handle hierarchical values (maxDepth > 1 or 0)
        if (maxDepth == 0 or maxDepth > 1) and instance.get("isComposition"):
            next_depth = 0 if maxDepth == 0 else maxDepth - 1
            for child_id in instance["relationships"].get("HasComponent", []):
                child_data = self.get_instance_values_by_id(child_id, startTime, endTime, next_depth, returnHistory)
                if child_data:
                    result[child_id] = child_data[child_id]
                    
        return { element_id: result }

    def get_object_types(self, namespace_uri: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return array of Type definitions (Simplified for N3uron)"""
        # For N3uron, we'll return generic types since they are dynamic
        return [
            {
                "elementId": "folder-type",
                "displayName": "FolderType",
                "namespaceUri": "http://n3uron.com/tags",
                "schema": {"type": "object", "description": "A grouping of tags or other groups"}
            },
            {
                "elementId": "measurement-type",
                "displayName": "MeasurementType",
                "namespaceUri": "http://n3uron.com/tags",
                "schema": {"type": "object", "properties": {"value": {"type": "number"}, "quality": {"type": "string"}, "timestamp": {"type": "string"}}}
            }
        ]

    def get_object_type_by_id(self, element_id: str) -> Optional[Dict[str, Any]]:
        """Return the schema for the requested type"""
        types = self.get_object_types()
        for t in types:
            if t["elementId"] == element_id:
                return t
        return None

    def get_relationship_types(self, namespace_uri: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return basic hierarchical relationship types"""
        return [
            {"elementId": "HasComponent", "displayName": "HasComponent", "namespaceUri": "http://n3uron.com/tags"},
            {"elementId": "ComponentOf", "displayName": "ComponentOf", "namespaceUri": "http://n3uron.com/tags"}
        ]

    def get_relationship_type_by_id(self, element_id: str) -> Optional[Dict[str, Any]]:
        """Return relationship type by ID"""
        for r in self.get_relationship_types():
            if r["elementId"] == element_id:
                return r
        return None

    def get_related_instances(self, element_id: str, relationship_type: Optional[str] = None) -> List[Dict[str, Any]]:
        """Return related objects (parent or children)"""
        instance = self.get_instance_by_id(element_id, values=False)
        if not instance:
            return []
            
        results = []
        # Support HasComponent (downward) and HasParent/ComponentOf (upward)
        if relationship_type == "HasComponent" or relationship_type is None:
            child_ids = instance.get("relationships", {}).get("HasComponent", [])
            for cid in child_ids:
                child = self.get_instance_by_id(cid)
                if child:
                    results.append(child)
                    
        if relationship_type == "ComponentOf" or relationship_type is None:
            parent_id = instance.get("parentId")
            if parent_id and parent_id != "/":
                parent = self.get_instance_by_id(parent_id)
                if parent:
                    results.append(parent)
                    
        return results

    def update_instance_value(self, element_id: str, value: Any) -> List[Dict[str, Any]]:
        """Handle value writes (Not yet implemented for real N3uron)"""
        # For now, return a failure record as per interface
        return [{
            "elementId": element_id,
            "success": False,
            "message": "Write operations are not currently supported for N3uron"
        }]

    def get_all_instances(self) -> List[Dict[str, Any]]:
        """Used by subscription worker"""
        return [ {k:v for k,v in i.items() if k != "records"} for i in self._instances]
