import json
import os
import sys
from datetime import datetime

# Add the server directory to path so we can import things
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from data_sources.n3uron.n3uron_data_source import N3uronDataSource

def test_n3uron_parser():
    print("Testing N3uron Parser...")
    
    # Initialize with local sample data path
    config = {
        "url": "http://localhost:3003/tag",
        "path": "/MainPlant/*"
    }
    
    ds = N3uronDataSource(config)
    
    # Load sample data
    sample_path = os.path.join(os.path.dirname(__file__), "Sample_Data.json")
    with open(sample_path, 'r') as f:
        sample_json = json.load(f)
    
    # Manually trigger the parser (since we can't hit the real URL)
    print("Parsing Sample_Data.json...")
    ds._parse_n3uron_tree(sample_json)
    
    # Verify instances
    instances = ds.get_instances()
    print(f"Total instances created: {len(instances)}")
    
    # Verify a specific tag
    # Path in JSON: Plant1 -> Kitting -> Active Power L1 (kW)
    # Expected ID: plant1/kitting/active-power-l1-(kw) (based on my replace logic)
    
    target_id = "plant1/kitting/active-power-l1-(kw)"
    val = ds.get_instance_values_by_id(target_id)
    
    if val and target_id in val:
        vqt = val[target_id]["data"][0]
        print(f"Verified Tag: {target_id}")
        print(f"  Value: {vqt['value']}")
        print(f"  Quality: {vqt['quality']}")
        print(f"  Timestamp: {vqt['timestamp']}")
    else:
        print(f"Error: Could not find tag {target_id} in parsed data.")
        # Print first few IDs to see what happened
        print("Generated IDs (first 5):")
        for i in instances[:5]:
            print(f"  - {i['elementId']}")

if __name__ == "__main__":
    test_n3uron_parser()
