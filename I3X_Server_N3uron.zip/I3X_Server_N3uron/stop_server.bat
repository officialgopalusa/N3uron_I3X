@echo off
echo Stopping I3X API Server on port 8080...
:: Use PowerShell to find the process ID and kill it, ignoring PID 0 (System Idle Process)
powershell -Command "Get-NetTCPConnection -LocalPort 8080 -ErrorAction SilentlyContinue | Where-Object { $_.OwningProcess -gt 0 } | ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }"
if %ERRORLEVEL% equ 0 (
    echo Server stop command issued.
) else (
    echo Server was not running or could not be stopped.
)
pause
